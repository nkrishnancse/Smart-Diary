<?php

include('connn.php');

if (isset($_POST['reg_name']))
     {
              if ($_FILES['reg_photo']['error'] > 0) 
			  {
                   echo "Error: " . $_FILES['reg_photo']['error'] . "<br />";
               
			  }
			   else
			     {
                   $validExtensions = array('.jpg', '.jpeg', '.gif', '.png');
                      $fileExtension = strrchr($_FILES['reg_photo']['name'], ".");
                          if (in_array($fileExtension, $validExtensions)) 
						  {
                             $newName = date("Ymd").''.time() . '' . $_FILES['reg_photo']['name'];
                             $destination = 'user/' .time().''. $newName;
                            if (move_uploaded_file($_FILES['reg_photo']['tmp_name'], $destination)) 
							{
            
			                   $catid=$_POST['reg_name'];$name=$_POST['reg_pwd'];$price =$_POST['reg_uname'];$description=$_POST['reg_email'];
$categoryadd = $conn->query("INSERT INTO user VALUES ('','$catid', '$price', '$price', '$destination')");
echo '<script type="text/javascript"> alert("Added Sucessfully");</script>';
 echo '<meta http-equiv=Refresh content="0;url=index.php">';
			
		                     }
                         } else
					 {
        echo 'You must upload an image...';
                     }
                 }
     }  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
<script type="text/javascript">
function verifyEmail(){    
var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
     if (document.alokm.email.value.search(emailRegEx) == -1) {
          alert("Please enter a valid email address.");
     }
   
 return false;
}

</script>

        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
  </head>
<body>
<img alt="" src="images/index.png" id="bgs">
    <div style="margin:0 auto;width:500px;">
 <br />
 <br />
<br />
<form method="post" name="form1" enctype="multipart/form-data" action="reg.php"><a href="index.php">
<img src="images/logo.png" width="550" style="margin-left:2px"/></a>
<div id="reg">
  <p><br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br>
    </p>
  <p> <br/><br/>
    <input type="text" name="reg_name" required="required" style="margin-left:100px;border:none" />
    <br /><br />&nbsp;&nbsp;
        <input type="text" name="reg_uname" required="required" style="margin-left:100px;border:none" />
        <br /><br />&nbsp;
        <input type="text" name="reg_email" required="required" onblur="verifyEmail()" style="margin-left:100px;border:none" />
        <br /><br />&nbsp;&nbsp;&nbsp;<br/>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="reg_pwd" required="required" style="margin-left:100px;border:none" />
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br/><br/><strong>Your Photo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </strong><input type="file" name="reg_photo" placeholder="upload your photo" ><br/>
        <input type="submit" name="submit" value="       " class="submit2" style="background:none;border:none;margin-top:10px;margin-left:0px;cursor:pointer;width:50px" />
      <a href="index.php"  style="background:none;border:none;margin-top:10px;margin-left:170px;cursor:pointer;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></p>
</div>
</form>
     </div>
		<h1 class="title"></h1>
    </body>
</html>