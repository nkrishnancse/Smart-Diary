<?php
session_start();
include_once "db/db.php";
if($_REQUEST['Mode'] == "Edit")
{
$sqlup="Select * from remin where re_id='".$_REQUEST['re_id']."'";
	$we=mysql_query($sqlup);
	$res=mysql_fetch_object($we);
}
if($_REQUEST['Mode'] == "Delete")
{
	$sqldel="Delete from remin where re_id='".$_REQUEST['re_id']."' ";
	mysql_query($sqldel);
	echo "<meta http-equiv='refresh' content='0;url=calendar.php'>";}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
        <script src="jquery-latest.js"></script>
        <!--Calendar-->
<link rel="stylesheet" href="cal/calendarview.css">
<script src="cal/prototype.js"></script>
<script src="cal/calendarview.js"></script>
<script type="text/javascript">
      function setupCalendars() {
        // Embedded Calendar
        Calendar.setup(
          {
            dateField: 'embeddedDateField',
            parentElement: 'embeddedCalendar'
          }
        )
        // Popup Calendar
        Calendar.setup(
          {
            dateField: 'popupDateField',
            triggerElement: 'popupDateField'
          }
        )
      }
      Event.observe(window, 'load', function() { setupCalendars() })
	$('#myModal').modal();
    </script>
    
    <!--Callender Start-->
<link rel="stylesheet" type="text/css" media="all" href="callender/jsDatePick_ltr.min.css" />
<script type="text/javascript" src="callender/jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"calcField",
			dateFormat:"%d-%M-%Y"
		
		});
	};
</script>
<!--Callender End-->
    </head>
<body>
<form name="f1" action="" method="post" enctype="multipart/form-data">
    <div id="top-bar">
    <div>
    <span style="float:left;"><img src="images/logopng.png" width="120" style="vertical-align:middle;border-top-left-radius: 5px;border-bottom-left-radius: 5px;border-top-right-radius: 5px;border-bottom-right-radius: 5px;" /></span>
    <span style="text-align:center;font-size:26px"><?php echo $name = $_SESSION['diary_user_name']; ?></span>
    <span style="float:right"><img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="50px" height="50px" /></span>
    <span style="float:right;margin-right:20px;"><a href="logout.php" style="text-decoration:none;color:#FFFFFF">logout</a></span>    </div>
    </div>

<table width="1000px" border="0" style="margin:0px auto;" cellpadding="0" cellspacing="0">
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
<tr>
<td width="905" rowspan="4">
<div style="height:600px; width:1000px; margin-top: 20px; margin-left: 10px; background-image: url(images/b.png); background-repeat: no-repeat;">

<div style="width:300px; height:450px; float:left; margin-top:95px; margin-left:60px;">
<div style="">
<div style="margin-top: -30px;">
<div class="calendar">
				<div id="embeddedCalendar" style="margin-right: 100px;"></div>
                
				</div>
</div>
<br />
<br />
<br />
<br />
<div style="height:210px; overflow-y: scroll; margin-top: 30px; margin-left: 15px;" align="center">
<?php
 $sql="Select * from remin
		WHERE `re_user` ='".$_SESSION['diary_user_id']."'";
$fr=mysql_query($sql);
while($row=mysql_fetch_object($fr))
{?>
<div style="color:#FFFFFF; height:40px; width:270px; text-align:left; overflow:hidden; background-image: url(images/rem.png); background-repeat: no-repeat;">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    
<a href="calendar.php?re_id=<?php echo $row->re_id ?>&amp;Mode=Edit">
<img src="images/edit.png" width="26" height="26"/></a>
&nbsp;&nbsp;
  <a href="calendar.php?re_id=<?php echo $row->re_id ?>&Mode=Delete" onClick="return confirm(' Are You Sure To Delete? ');" >
	  <img src="images/delete.png" width="20" height="20" /></a>
&nbsp;&nbsp;
<span style="font-size:14px;line-height:30px;">
<?php echo $row->re_date; ?>&nbsp;&nbsp;<?php echo $row->re_tit; ?></span></div>
<?php } ?>
</div>
</div>
<br />
</div>
<div style="width:480px; height:470px; float:left; margin-top:95px; margin-left:80px">
<br />
<div style="font-size:16px;color:#33b5e5;margin-left:20px;font-weight:bolder">
<h2 align="center">Add Reminders</h2><br />
Title
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="re_tit" style="margin-left:65px;width:240px" value="<?php echo $res->re_tit; ?>" required />
<br />
<br />
Date
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;
<input type="text" name="re_date" id="calcField" style="margin-left:65px;width:240px" value="<?php echo $res->re_date; ?>" required />
<br />
<br /> 
Time
&nbsp;&nbsp; &nbsp;&nbsp;
<input name="re_time" type="text" style="margin-left:70px;width:240px" value="<?php echo $res->re_time; ?>" required/>
<br />
<br /> 
Who
&nbsp;&nbsp; &nbsp;&nbsp;
<input name="re_who" type="text" style="margin-left:80px;width:240px" value="<?php echo $res->re_who; ?>" required/>
<br />
<br /> 
Location
&nbsp;&nbsp;&nbsp;&nbsp;
<input name="re_loc" type="text" style="margin-left:50px;width:240px" value="<?php echo $res->re_loc; ?>" required/>
<br />
<br /> 
Description
&nbsp;&nbsp;&nbsp;&nbsp;
<textarea name="re_desc" type="text" style="margin-left:30px;width:240px"  required><?php echo $res->re_desc; ?></textarea>
<br />
</div>

<div style="margin-left:175px;">
<?php if($_REQUEST['Mode'] == "Edit"){ ?>
<input type="submit" name="update" value="Update" class="submit2" style="width:80px; background-image: url(images/but.png);">
&nbsp;&nbsp;
<a href="calendar.php" style="text-decoration:none"><input type="button" value="New" class="submit2" style="width:80px;"></a>
<?php } else { ?>
<input type="submit" name="save" value="Save" class="submit2" style="width:80px;">
<?php } ?>
</div>
</div>
</div></td>
<td width="1" valign="top">
     
<div style="margin-top:120px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);">
<a href="home.php" style="text-decoration:none"><img src="images/diary.png" width="100" height="30" /></a></div>

<div style="margin-top:70px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="contacts.php" style="text-decoration:none"><img src="images/contacts.png" width="100" height="30" style="margin-left:-5px;" /></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="calendar.php" style="text-decoration:none"><img src="images/calendar.png" width="100" height="30" style="margin-left:-5px;"/></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="settings.php" style="text-decoration:none"></a><a href="settings.php" style="text-decoration:none"><img src="images/settings.png" width="100" height="30" style="margin-left:-5px;"/></a></div></td>
</tr>
</table>
</form>
</body>
</html>
<?php
if(isset($_REQUEST['save']))
{

$ins="INSERT INTO `remin` (`re_user` ,
							`re_tit` ,
							`re_date` ,
							`re_time`,
							`re_who`,
							`re_loc`,
							`re_desc`)
	  				VALUES ('".$_SESSION['diary_user_id']."', 
							'".$_REQUEST['re_tit']."',
							'".$_REQUEST['re_date']."', 
							'".$_REQUEST['re_time']."', 
							'".$_REQUEST['re_who']."', 
							'".$_REQUEST['re_loc']."', 
							'".$_REQUEST['re_desc']."')";
mysql_query($ins);
echo "<script type='text/javascript'> alert('Added Successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=calendar.php'>";
}
elseif(isset($_REQUEST['update']))
{
$sql = "UPDATE `remin` SET `re_tit` = '".$_REQUEST['re_tit']."',
							`re_date` = '".$_REQUEST['re_date']."',
							`re_time` = '".$_REQUEST['re_time']."',
							`re_who` = '".$_REQUEST['re_who']."',
							`re_loc` = '".$_REQUEST['re_loc']."',
							`re_desc` = '".$_REQUEST['re_desc']."'
					WHERE `re_id` ='".$_REQUEST['re_id']."' ";
					
mysql_query($sql);
echo "<script type='text/javascript'> alert('Updated Successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=calendar.php'>";
}
?>