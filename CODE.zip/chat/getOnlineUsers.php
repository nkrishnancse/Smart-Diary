<? 
session_start();
include("sql.php");
$username = $_SESSION["username"];
$sql = "select username from peer_userstatus where username<>'$username'";
$res = mysql_query($sql);
while ($users = mysql_fetch_array($res)) { 
 
$sql="Select * from user
		inner join contacts on contacts.con_user = user.user_id
		where user_uname ='".$users['username']."'";
$fr=mysql_query($sql);
$row=mysql_fetch_object($fr);
?>
<div onmouseover="chk('chk'+<?php echo $row->user_id; ?>)" onmouseout="chk2('chk'+<?php echo $row->user_id; ?>)" style="background:#333333;color:#FFFFFF;height:50px;border:#98afb8 1px solid;box-shadow: 1px 1px 1px #98afb8;" value="chk<?php echo $num; ?>">
<a href="javascript:void(0)" onClick="chatWith('<?=$users["username"]?>')" style="text-decoration:none;color:#FFFFFF">
<img src="images/chat.png" width="45px" height="35px" style="float:left;margin-left:10px;padding-top:7px;" />
&nbsp;&nbsp;
<span style="font-size:24px;line-height:50px;"><?php echo $row->user_name; ?></span>
<img src="<?php echo $row->user_photo; ?>" width="60px" height="50px" style="float:right;margin-right:30px" />
</a>
</div>
<br />


<? } ?>