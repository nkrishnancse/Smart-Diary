<?
$hostname	= 'localhost';
$sqluser	= 'root';
$sqlpass	= 'mysqli';
$dbName		= 'diary';

@mysql_connect($hostname, $sqluser, $sqlpass)  or die( 'Unable to connect SERVER' ) ;
@mysql_select_db( $dbName ) or die( 'Unable to connect DATABASE' ) ;

?>