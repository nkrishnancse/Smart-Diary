<?php 
ob_start(); 
session_start();
include_once "db/db.php"; 


$sel="select * from user where user_uname = '".$_GET['UserName']."' AND user_id != '".$_SESSION['diary_user_id']."'";
$from=mysql_query($sel);
$res=mysql_fetch_object($from);
if($res > 0)
{
echo "<font color='#CC0000'>User name already exist</font><br><input type='submit' name='update' value='Update' class='submit2' disabled style='width:250px'>";
}else{
echo "<input type='submit' name='update' value='Update' class='submit2' style='width:250px'>";
}


?>