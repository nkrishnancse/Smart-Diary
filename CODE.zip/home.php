<?php
session_start();
include_once "db/db.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<script type="text/javascript" src="book/jquery-1.4.4.min.js"></script>
		<script src="book/jquery.easing.1.3.js" type="text/javascript"></script>
		<script src="book/jquery.booklet.1.1.0.min.js" type="text/javascript"></script>

		<link href="book/jquery.booklet.1.1.0.css" type="text/css" rel="stylesheet" media="screen" />
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>

		<script src="cufon/cufon-yui.js" type="text/javascript"></script>
		<script src="cufon/ChunkFive_400.font.js" type="text/javascript"></script>
		<script src="cufon/Note_this_400.font.js" type="text/javascript"></script>
		<script type="text/javascript">
			Cufon.replace('h1,p,.b-counter');
			Cufon.replace('.book_wrapper a', {hover:true});
			Cufon.replace('.title', {textShadow: '1px 1px #C59471', fontFamily:'ChunkFive'});
			Cufon.replace('.reference a', {textShadow: '1px 1px #C59471', fontFamily:'ChunkFive'});
			Cufon.replace('.loading', {textShadow: '1px 1px #000', fontFamily:'ChunkFive'});
		</script>

    </head>
    <body>
    
    <div id="top-bar">
    <div>                  
    <span style="float:left;"><img src="images/logopng.png" width="120" style="vertical-align:middle;border-top-left-radius: 5px;border-bottom-left-radius: 5px;border-top-right-radius: 5px;border-bottom-right-radius: 5px;" /></span>
    <span style="text-align:center;font-size:26px"><?php echo $name = $_SESSION['diary_user_name']; ?></span>
    <span style="float:right"><img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="50px" height="50px" /></span>
    <span style="float:right;margin-right:20px;"><a href="logout.php" style="text-decoration:none;color:#FFFFFF">logout</a></span>    </div>
    </div>
      <table width="1000px" border="0" style="margin:0px auto;" cellpadding="0" cellspacing="0">
<tr>
<td width="905" rowspan="4">
  <div class="book_wrapper" style="margin-top:-30px;">
        
			<a id="next_page_button"></a>
			<a id="prev_page_button"></a>
			<div id="loading" class="loading">Loading pages...</div>
			<div id="mybook" style="display:none;">
				<div class="b-load">
 				            
              
					<?php 
					$con1 = date('Y');
					$con2 = date('Y', strtotime('-1 year'));
					$page = 0;
					$min = 0;
					$calc = 0;
					while($con1 > $con2)
					{ 
					$page++;
					$min++;
					$start = date('d-M-Y-D', strtotime('-'.$min.' days'));
					$div = $div.'-ATOZ-'.$start;
					$arr = explode('-',$start);
					$con1 = $arr[2];	
					} 
				$exp = explode('-ATOZ-',$div);
				while($min > 0)
				{
				$calc++;
				//echo $exp[$min];
				$arr = explode('-',$exp[$min]);
					$a = $arr[0];
					$b = $arr[3];
						if($b == "Mon"){ $b = "Monday"; }
					elseif($b == "Tue"){ $b = "Tuesday"; }
					elseif($b == "Wed"){ $b = "Wednesday"; }
					elseif($b == "Thu"){ $b = "Thursday"; }
					elseif($b == "Fri"){ $b = "Friday"; }
					elseif($b == "Sat"){ $b = "Saturday"; }
					elseif($b == "Sun"){ $b = "Sunday"; }
					$c = $arr[1].', '.$arr[2];								
					$con1 = $arr[2];
					if($con1 > $con2)
					{ ?>
					 <div>
						<h2 align='center' style='color:#999999'><?php echo $a; ?></h2>
                    <h3 align='center' style='color:#999999;padding-left:65px'><?php echo $b; ?>
                    <span style='float:right'><?php echo $c; ?></span></h3>
                    <hr style='margin-left:5px;border:#EEEEEE 1px solid;'/>
<?php
	if($arr[1] == "Jan"){ $spl = "01"; }
elseif($arr[1] == "Feb"){ $spl = "02"; }
elseif($arr[1] == "Mar"){ $spl = "03"; }
elseif($arr[1] == "Apr"){ $spl = "04"; }
elseif($arr[1] == "May"){ $spl = "05"; }
elseif($arr[1] == "Jun"){ $spl = "06"; }
elseif($arr[1] == "Jul"){ $spl = "07"; }
elseif($arr[1] == "Aug"){ $spl = "08"; }
elseif($arr[1] == "Sep"){ $spl = "09"; }
elseif($arr[1] == "Oct"){ $spl = "10"; }
elseif($arr[1] == "Nov"){ $spl = "11"; }
elseif($arr[1] == "Dec"){ $spl = "12"; }
$rdate= $a."-".$spl."-".$con1;
$re=0;
$sql="Select * from remin
		WHERE `re_date` = '".$rdate."' AND`re_user` ='".$_SESSION['diary_user_id']."'";
$fr=mysql_query($sql);
while($row=mysql_fetch_object($fr))
{ 
$re++; ?>
<div style="display:none;background:#333333;z-index:100;position:absolute;margin-top:20px;color:#eeeeee;height:340px;overflow:scroll;width:360px;padding:10px;" id="<?php echo $rdate."-V"; ?>" >
<img src="images/close.png" style="width:25px;float:right;border:none;height:25px;position:absolute;margin-top:-10px;margin-left:320px" onclick="chk2('<?php echo $rdate."-V"; ?>')"/>
<br />
<h3 style="text-decoration:underline"><?php echo $re."&nbsp;&nbsp;".$row->re_tit; ?></h3>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;:&nbsp;&nbsp;".$row->re_date; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time&nbsp;:&nbsp;&nbsp;".$row->re_time; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Who&nbsp;:&nbsp;&nbsp;".$row->re_who; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Location&nbsp;:&nbsp;&nbsp;".$row->re_loc; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Details&nbsp;:&nbsp;&nbsp;".$row->re_desc; ?></h4>
<br />
</div>
<?php } 
if($re > 0)
{
?>
<img src="images/reminder.png" style="width:100px;height:70px;border:none;position:absolute;margin-top:-52px;margin-left:-15px" onmouseover="chk('<?php echo $rdate."-V"; ?>')"/>
<h2 align="left" style="color:#FFFFFF;position:absolute;margin-top:-35px;margin-left:23px;transform:rotate(340deg);-ms-transform:rotate(340deg);-webkit-transform:rotate(340deg);"><?php echo $re; ?></h2>
<?php } ?>
                    <br />
				<div style="height:435px;overflow:scroll;width:380px">
                 <a class="demo" style="text-decoration:none" href="add.php?date=<?php echo $url; ?>&page=Today">
                    Write</a>
                <?php
				$sel = "select * from comments 
				where com_user = '".$_SESSION['diary_user_id']."' AND com_date = '". $exp[$min]."' ORDER BY com_id asc ";
				$from = mysql_query($sel);
				while($res = mysql_fetch_object($from))
				{
				echo $res->com_com;
				
				}
				?>
                 <br />
                 <br />
                <p>
				<?php
				$sel = "select * from audios 
				where aud_user = '".$_SESSION['diary_user_id']."' AND aud_date = '". $exp[$min]."' ORDER BY aud_id asc ";
				$from = mysql_query($sel);
				$count = 1;
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->aud_aud; ?>" style="text-decoration:none" target="_blank">
				Audio&nbsp;<?php echo $count; ?>
                </a>
				<?php $count ++; } ?>   
                </p>
                <br />
			    <p>
				<?php
				$sel = "select * from videos 
				where vid_user = '".$_SESSION['diary_user_id']."' AND vid_date = '". $exp[$min]."' ORDER BY vid_id asc ";
				$from = mysql_query($sel);
				$count = 1;
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->vid_vid; ?>" style="text-decoration:none" target="_blank">
				Video&nbsp;<?php echo $count; ?>
                </a>
				<?php $count ++; } ?>   
                </p>
                <br />

                <?php
				$sel = "select * from images 
				where img_user = '".$_SESSION['diary_user_id']."' AND img_date = '". $exp[$min]."' ORDER BY img_id asc ";
				$from = mysql_query($sel);
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->img_img; ?>" style="text-decoration:none" target="_blank">
				 <img src=<?php echo $res->img_img; ?> style="width:50px;height:50px;float:left" id="img"/>
                 </a>
				<?php } ?>   
               </div>
                    	
                    
    				</div>   
					<?php }
					else
					{ ?>
					<div>
					<br /><br /><br />
                    <img src="<?php echo $photo; ?>" height="250px" height="200px" id="img"/></a>
					<h1 align='center'><?php echo $name; ?></h1>
                </div>   
				<?php 	}
				$min--;
				}
				 ?>
                   <div>
                   
                   <h2 align="center" style="color:#999999"><?php $page++; echo date('d'); ?></h2>
                    	<h3 align="center" style="color:#999999;padding-left:65px"><?php $day = date('D');
								if($day == 'Mon'){ echo 'Monday'; }
								elseif($day == 'Tue'){ echo 'Tuesday'; }
								elseif($day == 'Wed'){ echo 'Wednesday'; }
								elseif($day == 'Thu'){ echo 'Thursday'; }
								elseif($day == 'Fri'){ echo 'Friday'; }
								elseif($day == 'Sat'){ echo 'Saturday'; }
								elseif($day == 'Sun'){ echo 'Sunday'; }
								else{ echo $day; } ?>
                                <span style="float:right">
                                <?php echo date('M, Y'); ?>                                </span></h3>
                                <hr style="margin-left:5px;border:#EEEEEE 1px solid;"/>
 					<?php $url = date('d-M-Y-D'); ?>                               
<?php
$re=0;
$sql="Select * from remin
		WHERE `re_date` = '".date('d-m-Y')."' AND`re_user` ='".$_SESSION['diary_user_id']."'";
$fr=mysql_query($sql);
while($row=mysql_fetch_object($fr))
{ 
$re++; ?>
<div style="display:none;background:#333333;z-index:100;position:absolute;margin-top:20px;color:#eeeeee;height:340px;overflow:scroll;width:360px;padding:10px;" id="<?php echo $url."-V"; ?>" >
<img src="images/close.png" style="width:25px;float:right;height:25px;position:absolute;margin-top:-10px;margin-left:320px" onclick="chk2('<?php echo $url."-V"; ?>')"/>
<br />
<h3 style="text-decoration:underline"><?php echo $re."&nbsp;&nbsp;".$row->re_tit; ?></h3>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;:&nbsp;&nbsp;".$row->re_date; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time&nbsp;:&nbsp;&nbsp;".$row->re_time; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Who&nbsp;:&nbsp;&nbsp;".$row->re_who; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Location&nbsp;:&nbsp;&nbsp;".$row->re_loc; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Details&nbsp;:&nbsp;&nbsp;".$row->re_desc; ?></h4>
<br />
</div>
<?php } 
if($re > 0)
{?>
<img src="images/reminder.png" style="width:100px;height:70px;border:none;position:absolute;margin-top:-52px;margin-left:-15px" onmouseover="chk('<?php echo $url."-V"; ?>')"/>

<h2 align="left" style="color:#FFFFFF;position:absolute;margin-top:-35px;margin-left:23px;transform:rotate(340deg);-ms-transform:rotate(340deg);-webkit-transform:rotate(340deg);"><?php echo $re; ?></h2>
<?php } ?>
                                <br />
				<div style="height:435px;overflow:scroll;width:380px">
                 <a class="demo" style="text-decoration:none" href="add.php?date=<?php echo $url; ?>&page=Today">
                    Write</a>
                <?php
				$sel = "select * from comments 
				where com_user = '".$_SESSION['diary_user_id']."' AND com_date = '". $url."' ORDER BY com_id asc ";
				$from = mysql_query($sel);
				while($res = mysql_fetch_object($from))
				{
				echo $res->com_com;
				
				}
				?>
                 <br />
                 <br />
                <p>
				<?php
				$sel = "select * from audios 
				where aud_user = '".$_SESSION['diary_user_id']."' AND aud_date = '". $url."' ORDER BY aud_id asc ";
				$from = mysql_query($sel);
				$count = 1;
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->aud_aud; ?>" style="text-decoration:none" target="_blank">
				Audio&nbsp;<?php echo $count; ?>
                </a>
				<?php $count ++; } ?>   
                </p>
                <br />
			    <p>
				<?php
				$sel = "select * from videos 
				where vid_user = '".$_SESSION['diary_user_id']."' AND vid_date = '". $url."' ORDER BY vid_id asc ";
				$from = mysql_query($sel);
				$count = 1;
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->vid_vid; ?>" style="text-decoration:none" target="_blank">
				Video&nbsp;<?php echo $count; ?>
                </a>
				<?php $count ++; } ?>   
                </p>
                <br />

                <?php
				$sel = "select * from images 
				where img_user = '".$_SESSION['diary_user_id']."' AND img_date = '". $url."' ORDER BY img_id asc ";
				$from = mysql_query($sel);
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->img_img; ?>" style="text-decoration:none" target="_blank">
				 <img src=<?php echo $res->img_img; ?> style="width:50px;height:50px;float:left" id="img"/>
                 </a>
				<?php } ?>   
               
               </div>

                    </div> 
                    
                    
                    <?php 
					$cons1 = date('Y');
					$cons2 = date('Y', strtotime('+1 year'));
					$mins = 0;
					while($cons1 < $cons2)
					{ 
					$mins++;
					$calcs = $page + $mins;
					$starts = date('d-M-Y-D', strtotime('+'.$mins.' days'));
					$arrs = explode('-',$starts);
					$as = $arrs[0];
					$bs = $arrs[3];
						if($bs == "Mon"){ $bs = "Monday"; }
					elseif($bs == "Tue"){ $bs = "Tuesday"; }
					elseif($bs == "Wed"){ $bs = "Wednesday"; }
					elseif($bs == "Thu"){ $bs = "Thursday"; }
					elseif($bs == "Fri"){ $bs = "Friday"; }
					elseif($bs == "Sat"){ $bs = "Saturday"; }
					elseif($bs == "Sun"){ $bs = "Sunday"; }
					$cs = $arrs[1].', '.$arrs[2];	
					$cons1 = $arrs[2];
					if($cons1 < $cons2)
					{ ?>
                    
				<div>
						<h2 align='center' style='color:#999999'><?php echo $as; ?></h2>
                    <h3 align='center' style='color:#999999;padding-left:65px'><?php echo $bs; ?>
                    <span style='float:right'><?php echo $cs; ?></span></h3>
                    <hr style='margin-left:5px;border:#EEEEEE 1px solid;'/>
                  
<?php
	if($arrs[1] == "Jan"){ $spls = "01"; }
elseif($arrs[1] == "Feb"){ $spls = "02"; }
elseif($arrs[1] == "Mar"){ $spls = "03"; }
elseif($arrs[1] == "Apr"){ $spls = "04"; }
elseif($arrs[1] == "May"){ $spls = "05"; }
elseif($arrs[1] == "Jun"){ $spls = "06"; }
elseif($arrs[1] == "Jul"){ $spls = "07"; }
elseif($arrs[1] == "Aug"){ $spls = "08"; }
elseif($arrs[1] == "Sep"){ $spls = "09"; }
elseif($arrs[1] == "Oct"){ $spls = "10"; }
elseif($arrs[1] == "Nov"){ $spls = "11"; }
elseif($arrs[1] == "Dec"){ $spls = "12"; }
$rdates= $as."-".$spls."-".$cons1;
$re=0;
$sql="Select * from remin
		WHERE `re_date` = '".$rdates."' AND`re_user` ='".$_SESSION['diary_user_id']."'";
$fr=mysql_query($sql);
while($row=mysql_fetch_object($fr))
{ 
$re++; ?>
<div style="display:none;background:#333333;z-index:100;position:absolute;margin-top:20px;color:#eeeeee;height:340px;overflow:scroll;width:360px;padding:10px;" id="<?php echo $rdates."-V"; ?>" >
<img src="images/close.png" style="width:25px;float:right;height:25px;border:none;position:absolute;margin-top:-10px;margin-left:320px" onclick="chk2('<?php echo $rdates."-V"; ?>')"/>
<br />
<h3 style="text-decoration:underline"><?php echo $re."&nbsp;&nbsp;".$row->re_tit; ?></h3>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;:&nbsp;&nbsp;".$row->re_date; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Time&nbsp;:&nbsp;&nbsp;".$row->re_time; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Who&nbsp;:&nbsp;&nbsp;".$row->re_who; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Location&nbsp;:&nbsp;&nbsp;".$row->re_loc; ?></h4>
<h4><?php echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Details&nbsp;:&nbsp;&nbsp;".$row->re_desc; ?></h4>
<br />
</div>
<?php } 
if($re > 0)
{
?>
<img src="images/reminder.png" style="width:100px;height:70px;border:none;position:absolute;margin-top:-52px;margin-left:-15px" onmouseover="chk('<?php echo $rdates."-V"; ?>')"/>

<h2 align="left" style="color:#FFFFFF;position:absolute;margin-top:-35px;margin-left:23px;transform:rotate(340deg);-ms-transform:rotate(340deg);-webkit-transform:rotate(340deg);"><?php echo $re; ?></h2>
<?php } ?>                  
                  
                  
                    <br />
				<div style="height:435px;overflow:scroll;width:380px">
                 <a class="demo" style="text-decoration:none" href="add.php?date=<?php echo $url; ?>&page=Today">
                    Write</a>
                <?php
				$sel = "select * from comments 
				where com_user = '".$_SESSION['diary_user_id']."' AND com_date = '".$starts."' ORDER BY com_id asc ";
				$from = mysql_query($sel);
				while($res = mysql_fetch_object($from))
				{
				echo $res->com_com;
				}
				?>
                 <br />
                 <br />
                <p>
				<?php
				$sel = "select * from audios 
				where aud_user = '".$_SESSION['diary_user_id']."' AND aud_date = '".$starts."' ORDER BY aud_id asc ";
				$from = mysql_query($sel);
				$count = 1;
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->aud_aud; ?>" style="text-decoration:none" target="_blank">
				Audio&nbsp;<?php echo $count; ?>
                </a>
				<?php $count ++; } ?>   
                </p>
                <br />
			    <p>
				<?php
				$sel = "select * from videos 
				where vid_user = '".$_SESSION['diary_user_id']."' AND vid_date = '".$starts."' ORDER BY vid_id asc ";
				$from = mysql_query($sel);
				$count = 1;
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->vid_vid; ?>" style="text-decoration:none" target="_blank">
				Video&nbsp;<?php echo $count; ?>
                </a>
				<?php $count ++; } ?>   
                </p>
                <br />

                <?php
				$sel = "select * from images 
				where img_user = '".$_SESSION['diary_user_id']."' AND img_date = '".$starts."' ORDER BY img_id asc ";
				$from = mysql_query($sel);
				while($res = mysql_fetch_object($from))
				{ ?>
                <a href="<?php echo $res->img_img; ?>" style="text-decoration:none" target="_blank">
				 <img src=<?php echo $res->img_img; ?> style="width:50px;height:50px;float:left" id="img"/>
                 </a>
				<?php } ?>   
               </div>
	
    				</div>            
					<?php }else
					{ ?> 
					<div><h1>Advance Happy New Year <?php echo $cons2; ?>
                    </h1><img src='images/newyear.jpg' alt='' height='200px'/></div>
               <?php
					}
	             } 
				 
if($_REQUEST['date'])
{	
$page_start = $page;		
}
elseif($_REQUEST['find_page'])
{
$page_start = $_REQUEST['find_page'];
}
else
{	 
$page_start = 0;				 
}
?>
				</div>
			</div>
		</div>


<div style="height:60px; width:850px; margin:0 auto; margin-top:-30px;">
<div style="background:#000000;height:50px;width:850px;margin-left:15px;padding-right:2px;-moz-border-radius:10px;-webkit-border-radius:10px;border-radius:10px;">
<form name="f4" action="" method="post" enctype="multipart/form-data">
  <input name="chk_page" type="hidden" value="<?php echo $page; ?>" />
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="home.php" style="text-decoration:none">
  <input type='button' value='First Page' class='submit'/>
  </a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="home.php?date=Today" style="text-decoration:none">
  <input type='button' value='Go To Today' class='submit'/>
  </a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  Custom Date&nbsp;:&nbsp;&nbsp;&nbsp;
  <select name="go_month" style="height:30px;" required>
    <option value="">Month</option>
    <option value="1">January</option>
    <option value="2">February</option>
    <option value="3">March</option>
    <option value="4">April</option>
    <option value="5">May</option>
    <option value="6">June</option>
    <option value="7">July</option>
    <option value="8">August</option>
    <option value="9">September</option>
    <option value="10">October</option>
    <option value="11">November</option>
    <option value="12">December</option>
  </select>
  <select name="go_date" style="height:30px;" required>
    <option value="">Date</option>
    <?php 
for($i=1;$i<=31;$i++)
{
echo "<option value='".$i."'>".$i."</option>";
} ?>
  </select>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input type='submit' value='Go >>' class='submit' name="find_date"/>
</form>
<br />
<br />
<br />
<div style="color:#FFFFFF"></div>
</div>
</div>

   <div>		</div></td>
<td width="1" valign="top">
     
     <div style="margin-top:159px;margin-left:-139px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);">
<a href="home.php" style="text-decoration:none"><img src="images/diary.png" width="100" height="30" /></a></div>

<div style="margin-top:70px;margin-left:-139px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="contacts.php" style="text-decoration:none"><img src="images/contacts.png" width="100" height="30" style="margin-left:-5px;" /></a></div>

<div style="margin-top:65px;margin-left:-139px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="calendar.php" style="text-decoration:none"><img src="images/calendar.png" width="100" height="30" style="margin-left:-5px;"/></a></div>

<div style="margin-top:65px;margin-left:-139px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="settings.php" style="text-decoration:none"></a><a href="settings.php" style="text-decoration:none"><img src="images/settings.png" width="100" height="30" style="margin-left:-5px;"/></a></div></td>
</tr>
</table>

        <!-- The JavaScript -->

    <script type="text/javascript">
			$(function() {
				var $mybook 		= $('#mybook');
				var $bttn_next		= $('#next_page_button');
				var $bttn_prev		= $('#prev_page_button');
				var $loading		= $('#loading');
				var $mybook_images	= $mybook.find('img');
				var cnt_images		= $mybook_images.length;
				var loaded			= 0;
				//preload all the images in the book,
				//and then call the booklet plugin

				$mybook_images.each(function(){
					var $img 	= $(this);
					var source	= $img.attr('src');
					$('<img/>').load(function(){
						++loaded;
						if(loaded == cnt_images){
							$loading.hide();
							$bttn_next.show();
							$bttn_prev.show();
							$mybook.show().booklet({
								name:               null,                            // name of the booklet to display in the document title bar
								width:              800,                             // container width
								height:             500,                             // container height
								speed:              600,                             // speed of the transition between pages
								direction:          'LTR',                           // direction of the overall content organization, default LTR, left to right, can be RTL for languages which read right to left
								startingPage:      <?php echo $page_start; ?>,                               // index of the first page to be displayed
								easing:             'easeInOutQuad',                 // easing method for complete transition
								easeIn:             'easeInQuad',                    // easing method for first half of transition
								easeOut:            'easeOutQuad',                   // easing method for second half of transition

								closed:             true,                           // start with the book "closed", will add empty pages to beginning and end of book
								closedFrontTitle:   null,                            // used with "closed", "menu" and "pageSelector", determines title of blank starting page
								closedFrontChapter: null,                            // used with "closed", "menu" and "chapterSelector", determines chapter name of blank starting page
								closedBackTitle:    null,                            // used with "closed", "menu" and "pageSelector", determines chapter name of blank ending page
								closedBackChapter:  null,                            // used with "closed", "menu" and "chapterSelector", determines chapter name of blank ending page
								covers:             false,                           // used with  "closed", makes first and last pages into covers, without page numbers (if enabled)

								pagePadding:        10,                              // padding for each page wrapper
								pageNumbers:        true,                            // display page numbers on each page

								hovers:             false,                            // enables preview pageturn hover animation, shows a small preview of previous or next page on hover
								overlays:           false,                            // enables navigation using a page sized overlay, when enabled links inside the content will not be clickable
								tabs:               false,                           // adds tabs along the top of the pages
								tabWidth:           60,                              // set the width of the tabs
								tabHeight:          20,                              // set the height of the tabs
								arrows:             false,                           // adds arrows overlayed over the book edges
								cursor:             'pointer',                       // cursor css setting for side bar areas

								hash:               false,                           // enables navigation using a hash string, ex: #/page/1 for page 1, will affect all booklets with 'hash' enabled
								keyboard:           true,                            // enables navigation with arrow keys (left: previous, right: next)
								next:               $bttn_next,          			// selector for element to use as click trigger for next page
								prev:               $bttn_prev,          			// selector for element to use as click trigger for previous page

								menu:               null,                            // selector for element to use as the menu area, required for 'pageSelector'
								pageSelector:       false,                           // enables navigation with a dropdown menu of pages, requires 'menu'
								chapterSelector:    false,                           // enables navigation with a dropdown menu of chapters, determined by the "rel" attribute, requires 'menu'

								shadows:            true,                            // display shadows on page animations
								shadowTopFwdWidth:  166,                             // shadow width for top forward anim
								shadowTopBackWidth: 166,                             // shadow width for top back anim
								shadowBtmWidth:     50,                              // shadow width for bottom shadow

								before:             function(){},                    // callback invoked before each page turn animation
								after:              function(){}                     // callback invoked after each page turn animation
							});
							Cufon.refresh();
						}
					}).attr('src',source);
				});
				
			});
        </script>
</body>
</html>
<?php
if(isset($_REQUEST['find_date']))
{

$chk1 = date('d');
$chk2 = date('m');
if($chk1 == $_REQUEST['go_date'] && $chk2 == $_REQUEST['go_month'])
{
echo "<meta http-equiv='refresh' content='0,home.php?date=Today' />";
}
elseif(($chk1 != $_REQUEST['go_date'] && $chk2 > $_REQUEST['go_month']) || ($chk1 > $_REQUEST['go_date'] && $chk2 == $_REQUEST['go_month']))
{
	$conf1 = date('Y');
	$conf2 = date('Y', strtotime('-1 year'));
	$minf = 0;
		while($conf1 > $conf2)
		{ 
		$minf++;
		$startf = date('d-m-Y-D', strtotime('-'.$minf.' days'));
		$arrf = explode('-',$startf);
		$conf1 = $arrf[2];
		$divf = $divf."-ATOZ-".$arrf[0]."-".$arrf[1];   
		} 
			$expf = explode('-ATOZ-',$divf);
			$pagef = 0;
			while($minf > -1)
			{
			$pagef++;
			$find = explode('-',$expf[$minf]);
			if($find[0] == $_REQUEST['go_date'] && $find[1] == $_REQUEST['go_month'])
			{
			echo "<meta http-equiv='refresh' content='0,home.php?find_page=".$pagef."' />";
			}
			$minf--;
			}
}else
{
	$conf1 = date('Y');
	$conf2 = date('Y', strtotime('+1 year'));
	$minf = 0;
	$page = $_REQUEST['chk_page'];
	while($conf1 < $conf2)
		{ 
		$minf++;
		$page ++;
		$startf = date('d-m-Y-D', strtotime('+'.$minf.' days'));
		$arrf = explode('-',$startf);
		$conf1 = $arrf[2];
		
		if($arrf[0] == $_REQUEST['go_date'] && $arrf[1] == $_REQUEST['go_month'])
			{
			echo "<meta http-equiv='refresh' content='0,home.php?find_page=".$page."' />";
			}
		} 
}			
}
?>

 <script type="text/javascript">
       	   
	   function chk(dval) {
  		   $('#'+dval).show('slow');
		 }

	   function chk2(dval) {
  		   $('#'+dval).hide('slow');
			 }

</script>