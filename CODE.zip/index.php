<?php
session_start();
include_once "db/db.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
        <style>
        input{
            font-height: 19px;
        }
            .btn{
                
        </style>
  </head>
<body>
<img alt="" src="images/index.png" id="bgs">
    <div style="margin:0 auto;width:500px;">
 <br />
 <br />
<br />

<form action="" method="post" name="form1" enctype="multipart/form-data">
<img src="images/logo.png" width="550" style="margin-left:2px"/>
<div id="login">
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />

<br>
<input style="margin-left:100px;border:none;height:20px" name="user_uname" required="" type="text">
<br><br>
<input style="margin-left:100px;border:none;height: 20px;" name="user_pwd" required="" type="password">
<br><br>
<input type="submit" name="submit" value="&nbsp;&nbsp;&nbsp;" class="btn" style="background:none;border:none;margin-top:10px;margin-left:0px;cursor:pointer;width:50px" />
<a href="reg.php"  style="background:none;border:none;margin-top:10px;margin-left:130px;cursor:pointer;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></div>
</form>
     </div>
		<h1 class="title"></h1>
    </body>
</html>

<?php
if(isset($_REQUEST['submit']))
{
$user_uname=$_REQUEST['user_uname'];
$user_pwd=$_REQUEST['user_pwd'];


$sqlup="Select * from user
	where user_uname='".$user_uname."' AND user_pwd='".$user_pwd."'";

	$we=mysql_query($sqlup);
	$res=mysql_fetch_object($we);

if($res > 0)
{
$_SESSION['diary_user_id']=$res->user_id;
$_SESSION['diary_user_uname']=$user_uname;
$_SESSION['username']=$user_uname;
$_SESSION['diary_user_name']=$res->user_name;
$_SESSION['diary_user_photo']=$res->user_photo;



	echo "<script type='text/javascript'> alert('Login Successfully');</script>";

	echo "<meta http-equiv='refresh' content='0;url=home.php'>";

}
else{ 	echo "<script type='text/javascript'> alert('Invalid Login');</script>";	}
}
?>