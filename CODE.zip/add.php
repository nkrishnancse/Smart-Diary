<?php
session_start();
include_once "db/db.php";
$arr = explode('-',$_REQUEST['date']);
$day = $arr[3];
		if($day == "Mon"){ $day = "Monday"; }
	elseif($day == "Tue"){ $day = "Tuesday"; }
	elseif($day == "Wed"){ $day = "Wednesday"; }
	elseif($day == "Thu"){ $day = "Thursday"; }
	elseif($day == "Fri"){ $day = "Friday"; }
	elseif($day == "Sat"){ $day = "Saturday"; }
	elseif($day == "Sun"){ $day = "Sunday"; }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
    </head>
    <body>
    <div id="top-bar">
    <div>
    <span style="text-align:center;font-size:26px"><?php echo $name = $_SESSION['diary_user_name']; ?></span>
    <span style="float:right"><img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="50px" height="50px" /></span>
    <span style="float:right;margin-right:20px;"><a href="logout.php" style="text-decoration:none;color:#FFFFFF">logout</a></span>    </div>
    </div>
<table width="1000px" border="0" style="margin:0px auto;" cellpadding="0" cellspacing="0">
<tr>
<td>
<div style="background:#33b5e5;height:60px;width:901px;Border-top-left-radius: 20px 20px;Border-top-right-radius: 20px 20px;border-left:10px solid #000000;border-right:10px solid #000000;border-top:10px solid #000000">
<span style="font-size:24px;padding-left:20px;line-height:60px;float:left">Edit This Day</span>
<span style="font-size:24px;padding-left:220px;line-height:60px;"><?php echo $arr[0].' - '.$day; ?></span>
<span style="font-size:24px;float:right;padding-right:20px;line-height:60px"><?php echo $arr[1].', '.$arr[2]; ?></span>
</div></td>
<td>&nbsp;</td>
</tr>
<tr>
<td width="905" rowspan="4">
<div style="background:#FFFFFF;height:500px;width:901px;Border-bottom-left-radius: 20px 20px;Border-bottom-right-radius: 20px 20px;border-left:10px solid #000000;border-right:10px solid #000000;border-bottom:10px solid #000000">
<form name="f1" method="post" action="" enctype="multipart/form-data">
<p style="padding:50px 50px 30px 50px">
<strong>Comments&nbsp;:&nbsp;</strong><textarea name="com_com" cols="75" rows="5" required></textarea>
&nbsp;
<input type='submit' value='Submit' class='submit2' name="com"/>
</p>
</form>
<form name="f2" method="post" action="" enctype="multipart/form-data">
<p style="padding:30px 50px 30px 50px">
<strong>Image&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>
<input name="img_img" type="file" required />
&nbsp;
<input type='submit' value='Submit' class='submit2' name="img"/>
</p>
</form>
<form name="f3" method="post" action="" enctype="multipart/form-data">
<p style="padding:30px 50px 30px 50px">
<strong>Audio&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>
<input name="aud_aud" type="file" required />
&nbsp;
<input type='submit' value='Submit' class='submit2' name="aud"/>
</p>
</form>
<form name="f4" method="post" action="" enctype="multipart/form-data">
<p style="padding:30px 50px 30px 50px">
<strong>Video&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>
<input name="vid_vid" type="file" required />
&nbsp;
<input type='submit' value='Submit' class='submit2' name="vid"/>
</p>
</form>
<?php 
if($_REQUEST['page'])
{
?>
<a href="home.php?date=<?php echo $_REQUEST['page']; ?>" style="text-decoration:none;float:right;margin-right:20px">
<input type='button' value='&nbsp;<< Go Back&nbsp;' class='submit2' /></a>
<?php } else { ?>
<a href="home.php?find_page=<?php echo $_REQUEST['find_page']; ?>" style="text-decoration:none;float:right;margin-right:20px">
<input type='button' value='&nbsp;<< Go Back&nbsp;' class='submit2' /></a>
<?php } ?>
</div>
</td>
<td width="1" valign="top">
     
     <div style="margin-top:120px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);">
<a href="home.php" style="text-decoration:none"><img src="images/diary.png" width="100" height="30" /></a></div>

<div style="margin-top:70px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="contacts.php" style="text-decoration:none"><img src="images/contacts.png" width="100" height="30" style="margin-left:-5px;" /></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="calendar.php" style="text-decoration:none"><img src="images/calendar.png" width="100" height="30" style="margin-left:-5px;"/></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="settings.php" style="text-decoration:none"></a><a href="settings.php" style="text-decoration:none"><img src="images/settings.png" width="100" height="30" style="margin-left:-5px;"/></a></div></td>
</tr>
</table>

</body>
</html>
<?php
if(isset($_REQUEST['com']))
{
$ins="INSERT INTO `comments` (`com_user` ,`com_com` ,`com_date`)
	  VALUES ('".$_SESSION['diary_user_id']."', '".$_REQUEST['com_com']."', '".$_REQUEST['date']."')";
mysql_query($ins);
echo "<script type='text/javascript'> alert('Added Sucessfully');</script>";
}elseif(isset($_REQUEST['img']))
{
$photo=$_FILES['img_img']['name'];
$time=date('d-m-y').'-'.date('G-i-s').'-';		
$image = $time.$photo;
$path = "img/$image";						
$file_tmp_name=$_FILES['img_img']['tmp_name'];
move_uploaded_file($file_tmp_name, $path);

$ins="INSERT INTO `images` (`img_user` ,`img_img` ,`img_date`)
	  VALUES ('".$_SESSION['diary_user_id']."', '".$path."', '".$_REQUEST['date']."')";
mysql_query($ins);
echo "<script type='text/javascript'> alert('Uploaded Sucessfully');</script>";
}
elseif(isset($_REQUEST['aud']))
{
$photo=$_FILES['aud_aud']['name'];
$time=date('d-m-y').'-'.date('G-i-s').'-';		
$image = $time.$photo;
$path = "aud/$image";						
$file_tmp_name=$_FILES['aud_aud']['tmp_name'];
move_uploaded_file($file_tmp_name, $path);

$ins="INSERT INTO `audios` (`aud_user` ,`aud_aud` ,`aud_date`)
	  VALUES ('".$_SESSION['diary_user_id']."', '".$path."', '".$_REQUEST['date']."')";
mysql_query($ins);
echo "<script type='text/javascript'> alert('Uploaded Sucessfully');</script>";
}
elseif(isset($_REQUEST['vid']))
{
$photo=$_FILES['vid_vid']['name'];
$time=date('d-m-y').'-'.date('G-i-s').'-';		
$image = $time.$photo;
$path = "vid/$image";						
$file_tmp_name=$_FILES['vid_vid']['tmp_name'];
move_uploaded_file($file_tmp_name, $path);

$ins="INSERT INTO `videos` (`vid_user` ,`vid_vid` ,`vid_date`)
	  VALUES ('".$_SESSION['diary_user_id']."', '".$path."', '".$_REQUEST['date']."')";
mysql_query($ins);
echo "<script type='text/javascript'> alert('Uploaded Sucessfully');</script>";
}
?>