<?php 
ob_start(); 
session_start();
include_once "db/db.php"; 


$sel="select * from user where user_uname = '".$_GET['UserName']."'";
$from=mysql_query($sel);
$res=mysql_fetch_object($from);
if($res > 0)
{
echo "<font color='#CC0000'>User name already exist</font><br><input type='submit' name='register' value='Register' class='btn' disabled>";
}else{
echo "<input type='submit' name='register' value='Register' class='btn'>";
}


?>