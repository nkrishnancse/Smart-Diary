<?php
session_start();
include_once "db/db.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
    </head>
    <body>
    <div id="top-bar">
    <div>
    <span style="float:left;"><img src="images/logopng.png" width="120" style="vertical-align:middle;border-top-left-radius: 5px;border-bottom-left-radius: 5px;border-top-right-radius: 5px;border-bottom-right-radius: 5px;" /></span>
    <span style="text-align:center;font-size:26px"><?php echo $name = $_SESSION['diary_user_name']; ?></span>
    <span style="float:right"><img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="50px" height="50px" /></span>
    <span style="float:right;margin-right:20px;"><a href="logout.php" style="text-decoration:none;color:#FFFFFF">logout</a></span>    </div>
    </div>
<table width="1000px" border="0" style="margin:0px auto;" cellpadding="0" cellspacing="0">
<tr>
<td>
<div style="background:#33b5e5;height:60px;width:901px;Border-top-left-radius: 20px 20px;Border-top-right-radius: 20px 20px;border-left:10px solid #000000;border-right:10px solid #000000;border-top:10px solid #000000">
<h2 align="center" style="font-size:24px;line-height:60px;">Update Your Details</h2>
</div></td>
<td>&nbsp;</td>
</tr>
<tr>
<td width="905" rowspan="4">
<div style="background:#FFFFFF;height:500px;width:901px;Border-bottom-left-radius: 20px 20px;Border-bottom-right-radius: 20px 20px;border-left:10px solid #000000;border-right:10px solid #000000;border-bottom:10px solid #000000">
<form action="" method="post" name="form2" enctype="multipart/form-data">
<p style="padding:50px 50px 30px 50px" align="center">
<br>
<br />
<br />
<br />

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
<strong>Name &nbsp;&nbsp;</strong>
<input type="text" name="reg_name" placeholder="enter your name" required value="<?php echo $_SESSION['diary_user_name']; ?>" >
<br>
<br />
<br />

<strong>User Name&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;</strong>
<input type="text" name="reg_uname" placeholder="enter user name" required onBlur="checkUname(this.value)" value="<?php echo $_SESSION['diary_user_uname']; ?>" readonly="readonly" >
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<strong>Password&nbsp;&nbsp;</strong>
<input type="password" name="reg_pwd" placeholder="enter password" required >
<br />
<br />
<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<strong>Your Photo&nbsp;&nbsp;&nbsp;</strong><input type="file" name="reg_photo" placeholder="upload your photo">
<br />
<br />
<div id="unamediv" align="center"><input type="submit" name="update" value="Update" class="submit2" style="width:250px"></div>
</p>
</form>
</div>
</td>
<td width="1" valign="top">
     
     <div style="margin-top:120px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);">
<a href="home.php" style="text-decoration:none"><img src="images/diary.png" width="100" height="30" /></a></div>

<div style="margin-top:70px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="contacts.php" style="text-decoration:none"><img src="images/contacts.png" width="100" height="30" style="margin-left:-5px;" /></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="calendar.php" style="text-decoration:none"><img src="images/calendar.png" width="100" height="30" style="margin-left:-5px;"/></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:100;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="settings.php" style="text-decoration:none"></a><a href="settings.php" style="text-decoration:none"><img src="images/settings.png" width="100" height="30" style="margin-left:-5px;"/></a></div></td>
</tr>
</table>

</body>
</html>
<script type="text/javascript">
function checkUname(UserName) {
	xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
						document.getElementById('unamediv').innerHTML=xmlhttp.responseText;
				}
			}
			xmlhttp.open("GET","ajax2.php?UserName="+UserName, true);
			xmlhttp.send(null);
	}
</script>
<?php
if(isset($_REQUEST['update']))
{
if($_FILES['reg_photo'] != "")
{
$pho = $_SESSION['diary_user_photo'];
unlink($pho);
$photo=$_FILES['reg_photo']['name'];
$time=date('d-m-y').'-'.date('G-i-s').'-';		
$image = $time.$photo;
$path = "user/$image";						
$file_tmp_name=$_FILES['reg_photo']['tmp_name'];
move_uploaded_file($file_tmp_name, $path);

$sql = "UPDATE `user` SET `user_photo` = '".$path."'
					WHERE `user_id` ='".$_SESSION['diary_user_id']."' ";
mysql_query($sql);
$_SESSION['diary_user_photo']=$path;
}
$sql = "UPDATE `user` SET `user_name` = '".$_REQUEST['reg_name']."',
						  `user_uname` = '".$_REQUEST['reg_uname']."',
						  `user_pwd` = '".$_REQUEST['reg_pwd']."' 
					WHERE `user_id` ='".$_SESSION['diary_user_id']."' ";
mysql_query($sql);
$_SESSION['diary_user_uname']=$_REQUEST['reg_uname'];
$_SESSION['diary_user_name']=$_REQUEST['reg_name'];

echo "<script type='text/javascript'> alert('Updated Successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=settings.php'>";
}
?>