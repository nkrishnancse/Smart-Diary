<?php
session_start();
include_once "db/db.php";

$sqlup="Select * from user
		inner join contacts on contacts.con_user = user.user_id
		where user_id='".$_SESSION['diary_user_id']."'";
	$we=mysql_query($sqlup);
	$res=mysql_fetch_object($we);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title><?php include('title.php'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
        <script src="jquery-latest.js"></script>
<? include("chat/include_chat.php"); ?>
<script>
var refreshRate = 10000;
function refreshOnlineUsers() {
	$.post("chat/getOnlineUsers.php" , {} , function (text){
		$("#onlineUsers").html(text);
	});
	setTimeout(refreshOnlineUsers , refreshRate);
}
$(function(){
	refreshOnlineUsers();
});
</script>
    </head>
<body>
    <div id="top-bar">
    <div>
    <span style="float:left;"><img src="images/logopng.png" width="120" style="vertical-align:middle;border-top-left-radius: 5px;border-bottom-left-radius: 5px;border-top-right-radius: 5px;border-bottom-right-radius: 5px;" /></span>
    <span style="text-align:center;font-size:26px"><?php echo $name = $_SESSION['diary_user_name']; ?></span>
    <span style="float:right"><img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="50px" height="50px" /></span>
    <span style="float:right;margin-right:20px;"><a href="logout.php" style="text-decoration:none;color:#FFFFFF">logout</a></span>    </div>
    </div>
<table width="1000px" border="0" style="margin:0px auto;" cellpadding="0" cellspacing="0">
<tr>
<td>
<div style="background:#33b5e5;height:60px;width:901px;Border-top-left-radius: 20px 20px;Border-top-right-radius: 20px 20px;border-left:10px solid #000000;border-right:10px solid #000000;border-top:10px solid #000000">
<h2 align="center" style="font-size:24px;line-height:60px;">Contacts</h2>
</div></td>
<td>&nbsp;</td>
</tr>
<tr>
<td width="905" rowspan="4">
<div style="background:#EFEFEF;height:500px;width:901px;Border-bottom-left-radius: 20px 20px;Border-bottom-right-radius: 20px 20px;border-left:10px solid #000000;border-right:10px solid #000000;border-bottom:10px solid #000000">

<div style="width:380px;height:450px;float:left;border:#CCCCCC 2px solid;box-shadow: 2px 2px 2px #CCCCCC;margin-top:10px;margin-left:30px;">
<div style="color:#33b5e5;padding:10px 10px 10px 10px;">
<h3>ME</h3>
<br />
<div value="<?php echo $_SESSION['diary_user_id']; ?>" id="mine">
<div style="background:#33b5e5;color:#FFFFFF;height:50px;border:#98afb8 1px solid;box-shadow: 1px 1px 1px #98afb8;">
&nbsp;&nbsp;<span style="font-size:24px;line-height:50px;"><?php echo $_SESSION['diary_user_name']; ?></span>
<img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="60px" height="50px" style="float:right;margin-right:30px" />
</div>
</div>
<br />
<br />

<h3>Online Users</h3>
<br />
<div style="overflow:scroll;">
<div id="onlineUsers">

</div>
</div>
</div>
<br />
</div>
<div id="me" style="display:block;width:430px;height:450px;float:left;border:#CCCCCC 2px solid;margin-top:10px;margin-left:20px;background:#FFFFFF">
<br />
<form name="f1" action="" method="post" enctype="multipart/form-data">
<img src="<?php echo $photo = $_SESSION['diary_user_photo']; ?>" width="130px" height="140px" style="float:left;margin-left:30px;border:1px #CCCCCC solid" />
<div style="background:#33b5e5;width:200px;height:100px;float:right;margin-top:20px;margin-right:20px;text-align:center">
<span style="font-size:30px;line-height:100px;color:#FFFFFF"><?php echo $_SESSION['diary_user_name']; ?></span>
</div>
<br />
<div style="font-size:16px;color:#33b5e5;margin-top:150px;margin-left:20px;font-weight:bolder">
Home Phone&nbsp;&nbsp;:&nbsp;&nbsp;<input name="con_home" type="text" style="margin-left:20px;width:240px" value="<?php echo $res->con_home; ?>" />
<br />
Mobile Phone&nbsp;&nbsp;:&nbsp;&nbsp;<input name="con_mobile" type="text" style="margin-left:14px;width:240px" value="<?php echo $res->con_mobile; ?>"/>
<br />
Fax&nbsp;&nbsp;:&nbsp;&nbsp;<input name="con_fax" type="text" style="margin-left:90px;width:240px" value="<?php echo $res->con_fax; ?>"/>
<br />
Email&nbsp;&nbsp;:&nbsp;&nbsp;<input name="con_email" type="text" style="margin-left:75px;width:240px" value="<?php echo $res->con_email; ?>"/>
<br />
Facebook&nbsp;&nbsp;:&nbsp;&nbsp;<input name="con_fb" type="text" style="margin-left:40px;width:240px" value="<?php echo $res->con_fb; ?>"/>
<br />
Website&nbsp;&nbsp;:&nbsp;&nbsp;<input name="con_web" type="text" style="margin-left:55px;width:240px" value="<?php echo $res->con_web; ?>"/>
</div>

<div style="margin-left:175px;">
<input type="submit" name="update" value="Update" class="submit2" style="width:80px;">
</div>
</form>
</div>
<form name="f2" action="" method="post" enctype="multipart/form-data">
<?php 
$sqls="Select * from user
		inner join contacts on contacts.con_user = user.user_id
		where user_id !='".$_SESSION['diary_user_id']."' order by user_name asc";
$frs=mysql_query($sqls);
while($rows=mysql_fetch_object($frs))
{
?>
<div id="chk<?php echo $rows->user_id; ?>" style="display:none;width:430px;height:450px;float:left;border:#CCCCCC 2px solid;margin-top:10px;margin-left:20px;background:#FFFFFF">
<br />
<img src="<?php echo $rows->user_photo; ?>" width="130px" height="140px" style="float:left;margin-left:30px;border:1px #CCCCCC solid" />
<div style="background:#33b5e5;width:200px;height:100px;float:right;margin-top:20px;margin-right:20px;text-align:center">
<span style="font-size:30px;line-height:100px;color:#FFFFFF"><?php echo $rows->user_name; ?></span>
</div>
<br />
<div style="font-size:16px;color:#33b5e5;margin-top:160px;margin-left:20px;font-weight:bolder">
Home Phone&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows->con_home; ?>
<br />
<br />
Mobile Phone&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows->con_mobile; ?>
<br />
<br />
Fax&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows->con_fax; ?>
<br />
<br />
Email&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows->con_email; ?>
<br />
<br />
Facebook&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows->con_fb; ?>
<br />
<br />
Website&nbsp;&nbsp;:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $rows->con_web; ?>
</div>
</div>
<?php } ?>
</form>
</div></td>
<td width="1" valign="top">
     
     <div style="margin-top:120px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);">
<a href="home.php" style="text-decoration:none"><img src="images/diary.png" width="100" height="30" /></a></div>

<div style="margin-top:70px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="contacts.php" style="text-decoration:none"><img src="images/contacts.png" width="100" height="30" style="margin-left:-5px;" /></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="calendar.php" style="text-decoration:none"><img src="images/calendar.png" width="100" height="30" style="margin-left:-5px;"/></a></div>

<div style="margin-top:65px;margin-left:-148px;z-index:50;transform:rotate(90deg);-ms-transform:rotate(90deg);-webkit-transform:rotate(90deg);"><a href="settings.php" style="text-decoration:none"></a><a href="settings.php" style="text-decoration:none"><img src="images/settings.png" width="100" height="30" style="margin-left:-5px;"/></a></div></td>
</tr>
</table>

</body>
</html>


 <script type="text/javascript">
                 $(document).ready(function () {
                    $('#mine').mouseover(function () {
                       $('#me').show('slow');
                });
               });
			   
			   
	   function chk(dval) {
  		   $('#'+dval).show('fast');
		   $('#me').hide('fast');
			 }

	   function chk2(dval) {
  		   $('#'+dval).hide('fast');
			 }

</script>
<?php
if(isset($_REQUEST['update']))
{
$sql = "UPDATE `contacts` SET `con_home` = '".$_REQUEST['con_home']."',
								`con_mobile` = '".$_REQUEST['con_mobile']."',
								`con_fax` = '".$_REQUEST['con_fax']."',
								`con_email` = '".$_REQUEST['con_email']."',
								`con_fb` = '".$_REQUEST['con_fb']."',
								`con_web` = '".$_REQUEST['con_web']."'
					WHERE `con_user` ='".$_SESSION['diary_user_id']."' ";
					
mysql_query($sql);
echo "<script type='text/javascript'> alert('Updated Successfully');</script>";
echo "<meta http-equiv='refresh' content='0;url=contacts.php'>";
}
?>