<?php
session_start();
include_once "db/db.php";
mysql_query("DELETE FROM `peer_userstatus` WHERE `username`  = '".$_SESSION['diary_user_uname']."'");
session_destroy();
echo "<meta http-equiv='refresh' content='0;url=index.php'>";
?>